getPoint(P, X, Y, DIR):- position(X,Y,DIR,P).
