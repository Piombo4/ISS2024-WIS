position(1,4,down,wastein).
position(3,1,right,burnin).
position(0,0,down,home).
position(4,3,up,burnout).
position(5,4,down,ashout).
